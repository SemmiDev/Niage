package com.almazira;

import java.util.ArrayList;
import java.util.UUID;

public class Account {
    private String almazira_19071016_id;
    private String almazira_19071016_name;
    private String almazira_19071016_email;
    private EWallet almazira_19071016_wallet;
    private ArrayList<TransferLog> almazira_19071016_transferLog;
    private ArrayList<TopUpLog> almazira_19071016_topUpLog;

    public Account(String almazira_19071016_name, String almazira_19071016_email) {
        this.almazira_19071016_id = UUID.randomUUID().toString();
        this.almazira_19071016_name = almazira_19071016_name;
        this.almazira_19071016_email = almazira_19071016_email;
        this.almazira_19071016_wallet = new EWallet();
        this.almazira_19071016_transferLog = new ArrayList<>();
        this.almazira_19071016_topUpLog = new ArrayList<>();
    }

    public void addLog(TopUpLog log) {
        this.almazira_19071016_topUpLog.add(log);
    }

    public ArrayList<TransferLog> getTransferLog() {
        return almazira_19071016_transferLog;
    }

    public void setTopUpLog(ArrayList<TopUpLog> almazira_19071016_topUpLog) {
        this.almazira_19071016_topUpLog = almazira_19071016_topUpLog;
    }

    public void setTransferLog(ArrayList<TransferLog> almazira_19071016_transferLog) {
        this.almazira_19071016_transferLog = almazira_19071016_transferLog;
    }

    public ArrayList<TopUpLog> getTopUpLog() {
        return almazira_19071016_topUpLog;
    }

    public String getId() {
        return almazira_19071016_id;
    }

    public void setId(String id) {
        this.almazira_19071016_id = id;
    }

    public String getName() {
        return almazira_19071016_name;
    }

    public void setName(String almazira_19071016_name) {
        this.almazira_19071016_name = almazira_19071016_name;
    }

    public String getEmail() {
        return almazira_19071016_email;
    }

    public void setEmail(String almazira_19071016_email) {
        this.almazira_19071016_email = almazira_19071016_email;
    }

    public EWallet getWallet() {
        return almazira_19071016_wallet;
    }

    public void setWallet(EWallet almazira_19071016_wallet) {
        this.almazira_19071016_wallet = almazira_19071016_wallet;
    }

    public void addTransferLog(TransferLog log) {
        this.almazira_19071016_transferLog.add(log);
    }
}
