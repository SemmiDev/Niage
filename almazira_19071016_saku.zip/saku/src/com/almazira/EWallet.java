package com.almazira;

import java.util.UUID;

public class EWallet {
    private String id;
    private Double almazira_19071016_balance;

    public EWallet() {
        this.id = UUID.randomUUID().toString();
        this.almazira_19071016_balance = 0d;
    }

    public void addBalance(double amount) {
        this.almazira_19071016_balance += amount;
    }

    public void subBalance(double amount) {
        this.almazira_19071016_balance -= amount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Double getBalance() {
        return almazira_19071016_balance;
    }

    public void setBalance(Double balance) {
        this.almazira_19071016_balance = balance;
    }
}
