package com.almazira;

import java.util.ArrayList;
import java.util.Scanner;

public class Application {

    static ArrayList<Account> almazira_19071016_fakeDB = new ArrayList<>();

    public static void main(String[] args) {
        mainApp();
    }

    private static void mainApp() {
        System.out.println("---------------------------------");
        System.out.println("               SAKU              ");
        System.out.println("---------------------------------");

        System.out.println("0. PROFILE");
        System.out.println("1. Create Account");
        System.out.println("2. TOP UP");
        System.out.println("3. Create Transaction");
        System.out.println("4. LOG OUT \n");

        Scanner almazira_19071016_scanner = new Scanner(System.in);
        Boolean almazira_19071016_next = true;

        while (almazira_19071016_next) {
            System.out.print("NO : ");
            int almazira_19071016_choice = almazira_19071016_scanner.nextInt();

            if (almazira_19071016_choice == 1) {
                createAccount();
            } else if (almazira_19071016_choice == 2) {
                TopUP();
            } else if (almazira_19071016_choice == 3) {
                transaction();
            }else if (almazira_19071016_choice == 0) {
              profile();
            } else {
                System.exit(0);
            }

            int isNext = almazira_19071016_scanner.nextInt();
            if (isNext == 1) {
                almazira_19071016_next = true;
            } else {
                almazira_19071016_next = false;
            }
        }
    }

    private static void profile() {
        Scanner almazira_19071016_scanner = new Scanner(System.in);
        System.out.print("Email    : ");
        String almazira_19071016_email = almazira_19071016_scanner.nextLine();

        Account almazira_19071016_account = null;
        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(almazira_19071016_email)) {
                almazira_19071016_account = almazira_19071016_fakeDB.get(i);
            }
        }

        if (almazira_19071016_account == null) {
            System.out.println("ACCOUNT NOT FOUND, PLEASE REGISTER");
            createAccount();
        }

        System.out.println("ID    : " + almazira_19071016_account.getId());
        System.out.println("NAME  : " + almazira_19071016_account.getName());
        System.out.println("EMAIL :"  + almazira_19071016_account.getEmail());

        System.out.println("----------------TRANSFER LOG------------");
        almazira_19071016_account.getTransferLog().forEach(x -> {
            System.out.println("-----------------------------------------");
            System.out.println("ID :" + x.getID());
            System.out.println("FROM :" + x.getFrom());
            System.out.println("TO :" + x.getTo());
            System.out.println("AT :" + x.getTransferAt());
        });

        System.out.println("----------------TOP UP LOG------------");
        almazira_19071016_account.getTopUpLog().forEach(x -> {
            System.out.println("-----------------------------------------");
            System.out.println("ID :" + x.getId());
            System.out.println("SOURCE :" + x.getSource());
            System.out.println("AMOUNT :" + x.getAmount());
        });

        mainApp();
    }

    private static void createAccount() {
        Scanner almazira_19071016_scanner = new Scanner(System.in);
        System.out.print("FullName : ");
        String name = almazira_19071016_scanner.nextLine();

        System.out.print("Email    : ");
        String almazira_19071016_email = almazira_19071016_scanner.nextLine();

        Account almazira_19071016_account = new Account(name, almazira_19071016_email);
        almazira_19071016_fakeDB.add(almazira_19071016_account);

        System.out.println("success");
        mainApp();
    }

    private static void TopUP() {
        Scanner almazira_19071016_scanner = new Scanner(System.in);
        Scanner almazira_19071016_scanner2 = new Scanner(System.in);

        System.out.print("Email  : ");
        String almazira_19071016_email = almazira_19071016_scanner.nextLine();

        System.out.print("Source : ");
        String almazira_19071016_source = almazira_19071016_scanner2.nextLine();

        System.out.print("Amount : Rp.");
        double amount = almazira_19071016_scanner2.nextDouble();

        Account almazira_19071016_account = null;
        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(almazira_19071016_email)) {
                almazira_19071016_account = almazira_19071016_fakeDB.get(i);
            }
        }

        if (almazira_19071016_account == null) {
            System.out.println("ACCOUNT NOT FOUND, PLEASE REGISTER");
            createAccount();
        }

        TopUpLog LOG = new TopUpLog(almazira_19071016_source, amount);

        almazira_19071016_fakeDB.forEach(x -> {
            if (x.getEmail().equalsIgnoreCase(almazira_19071016_email)) {
                x.getWallet().addBalance(amount);
                // administration
                x.getWallet().subBalance(100);
                x.addLog(LOG);
            }
        });

        System.out.println("TOP UP SUCCESS");
        mainApp();
    }

    private static void transaction() {
        double biayaTransaksi = 100d;
        Scanner almazira_19071016_scanner = new Scanner(System.in);

        System.out.print("Email Source : ");
        String almazira_19071016_email = almazira_19071016_scanner.nextLine();

        Account almazira_19071016_source = null;
        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(almazira_19071016_email)) {
                almazira_19071016_source = almazira_19071016_fakeDB.get(i);
            }
        }

        if (almazira_19071016_source == null) {
            System.out.println("ACCOUNT NOT FOUND, PLEASE REGISTER");
            createAccount();
        }

        System.out.print("Email target  : ");
        String almazira_19071016_target = almazira_19071016_scanner.nextLine();
        Account target = null;

        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(almazira_19071016_target)) {
                target = almazira_19071016_fakeDB.get(i);
            }
        }

        if (target == null) {
            System.out.println("ACCOUNT NOT FOUND, PLEASE REGISTER");
            createAccount();
        }

        System.out.print("Masukkan amount  : ");
        Double amount = almazira_19071016_scanner.nextDouble();

        TransferLog LOG = new TransferLog(almazira_19071016_source, target);
        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(almazira_19071016_source.getEmail())) {
                almazira_19071016_fakeDB.get(i).getWallet().subBalance(amount);
                almazira_19071016_fakeDB.get(i).getWallet().subBalance(biayaTransaksi);
                almazira_19071016_fakeDB.get(i).addTransferLog(LOG);
            }
        }

        for (int i = 0; i < almazira_19071016_fakeDB.size(); i++) {
            if (almazira_19071016_fakeDB.get(i).getEmail().equalsIgnoreCase(target.getEmail())) {
                almazira_19071016_fakeDB.get(i).getWallet().addBalance(amount);
            }
        }

        System.out.println("TRANSACTION SUCCESSFULLY");
        mainApp();
    }
}
