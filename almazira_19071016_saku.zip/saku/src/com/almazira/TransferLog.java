package com.almazira;

import java.time.LocalDateTime;
import java.util.UUID;

public class TransferLog {
    private String ID;
    private Account almazira_19071016_from;
    private Account almazira_19071016_to;
    private LocalDateTime almazira_19071016_transferAt;

    public TransferLog(Account almazira_19071016_from, Account almazira_19071016_to) {
        this.ID = UUID.randomUUID().toString();
        this.almazira_19071016_from = almazira_19071016_from;
        this.almazira_19071016_to = almazira_19071016_to;
        this.almazira_19071016_transferAt = LocalDateTime.now();
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public Account getFrom() {
        return almazira_19071016_from;
    }

    public void setFrom(Account almazira_19071016_from) {
        this.almazira_19071016_from = almazira_19071016_from;
    }

    public Account getTo() {
        return almazira_19071016_to;
    }

    public void setTo(Account almazira_19071016_to) {
        this.almazira_19071016_to = almazira_19071016_to;
    }

    public LocalDateTime getTransferAt() {
        return almazira_19071016_transferAt;
    }

    public void setTransferAt(LocalDateTime almazira_19071016_transferAt) {
        this.almazira_19071016_transferAt = almazira_19071016_transferAt;
    }
}
