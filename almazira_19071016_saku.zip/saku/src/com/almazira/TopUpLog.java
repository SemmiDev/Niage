package com.almazira;

import java.util.UUID;

public class TopUpLog {
    private String id;
    private String almazira_19071016_source;
    private double almazira_19071016_amount;

    public TopUpLog(String almazira_19071016_source, double almazira_19071016_amount) {
        this.id = UUID.randomUUID().toString();
        this.almazira_19071016_source = almazira_19071016_source;
        this.almazira_19071016_amount = almazira_19071016_amount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSource() {
        return almazira_19071016_source;
    }

    public void setSource(String almazira_19071016_source) {
        this.almazira_19071016_source = almazira_19071016_source;
    }

    public double getAmount() {
        return almazira_19071016_amount;
    }

    public void setAmount(double almazira_19071016_amount) {
        this.almazira_19071016_amount = almazira_19071016_amount;
    }
}
