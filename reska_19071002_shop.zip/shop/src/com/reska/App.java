package com.reska;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;

public class App {
    static ArrayList<Person> reska_19071002_personList = new ArrayList<>();
    static ArrayList<Product> reska_19071002_productList = new ArrayList<>();
    static ArrayList<Order> reska_19071002_orderList = new ArrayList<>();

    public static void main(String[] args) {
        mulai();
    }

    private static void mulai() {
        Scanner reska_19071002_scanner = new Scanner(System.in);
        Boolean reska_19071002_next = true;

        while (reska_19071002_next) {
            header();
            System.out.print("Masukkan no: ");
            int pilihan = reska_19071002_scanner.nextInt();

            if (pilihan == 1) {
                buatAkun();
            }else if (pilihan == 2) {
                buatProduk();
            }else if (pilihan == 3) {
                beliProduk();
            }else if (pilihan == 4) {
                detilAkun();
            }else {
                footer();
                System.exit(0);
            }

            int isNext = reska_19071002_scanner.nextInt();
            if (isNext == 1) {
                reska_19071002_next = true;
            }else {
                reska_19071002_next = false;
            }
        }
    }

    private static void detilAkun() {
        Scanner reska_19071002_scanner = new Scanner(System.in);
        System.out.print("Masukkan nama anda   : ");
        String reska_19071002_person = reska_19071002_scanner.nextLine();
        Person reska_19071002_person1 = null;

        for (int i = 0; i < reska_19071002_personList.size(); i++) {
            if (reska_19071002_personList.get(i).getNama().equalsIgnoreCase(reska_19071002_person)) {
                reska_19071002_person1 = reska_19071002_personList.get(i);
            }
        }

        System.out.println("------------------DETAILS------------------");
        System.out.println("nama  : " + reska_19071002_person1.getNama());
        System.out.println("email : " + reska_19071002_person1.getEmail());
        System.out.println("saldo : " + reska_19071002_person1.getSaldo());
        System.out.println("produk yang dijual : ");
        if (reska_19071002_person1.getProductsYangDijual() == null) {}
        else {
            tampilkanDetailProduk(reska_19071002_person1.getProductsYangDijual());
        }

        System.out.println("produk yang dibeli : ");
        if (reska_19071002_person1.getProductsYangDibeli() == null) {}
        else {
            tampilkanDetailProduk(reska_19071002_person1.getProductsYangDibeli());
        }

        mulai();
    }

    private static void tampilkanDetailProduk(ArrayList<Product> reska_19071002_productList) {
        reska_19071002_productList.forEach(a -> {
            System.out.println("----------------------------");
            System.out.println("ID    : " + a.getId());
            System.out.println("NAMA  : " + a.getNamaProduk());
            System.out.println("QTY   : " + a.getQty());
            System.out.println("HARGA : " + a.getHargaProduk());
        });
    }

    private static void showYangDijual(ArrayList<Person> reska_19071002_persons) {
        for (Person reska_19071002_person : reska_19071002_persons) {
            reska_19071002_person.getProductsYangDijual().forEach(y -> {
                System.out.println("----------------------------");
                System.out.println("ID    : " + y.getId());
                System.out.println("NAMA  : " + y.getNamaProduk());
                System.out.println("QTY   : " + y.getQty());
                System.out.println("HARGA : " + y.getHargaProduk());
            });
        }
    }

    private static void tampilkanListProdukWithoutPembeli(Person namaPembeli) {
        ArrayList<Person> reska_19071002_listss = new ArrayList<>();

        for (Person x : reska_19071002_personList) {
            if (x.getNama().equalsIgnoreCase(namaPembeli.getNama())) {}
            else {
                reska_19071002_listss.add(x);
            }
        }

        showYangDijual(reska_19071002_listss);
    }

    private static void beliProduk() {
        Scanner reska_19071002_scanner = new Scanner(System.in);
        System.out.print("Masukkan nama anda   : ");
        String name = reska_19071002_scanner.nextLine();
        Person akunPembeli = getAccount(name);

        tampilkanListProdukWithoutPembeli(akunPembeli);

        System.out.println("Masukkan ID produk yang mau dibeli : ");
        String reska_19071002_idProduk = reska_19071002_scanner.nextLine();

        Product reska_19071002_produk = getProdukById(reska_19071002_idProduk);

        System.out.println("Masukkan banyak produk yang dibeli : ");
        int amount = reska_19071002_scanner.nextInt();

        // tambah produk ke yg membeli
        // kurangi saldo
        if (reska_19071002_produk.getQty() < amount) {
            System.out.println("STOK TIDAK MENCUKUPI");
            mulai();
        }
        Double hargaProduk = reska_19071002_produk.getHargaProduk() * amount;

        Order order = new Order();
        order.setID(UUID.randomUUID().toString());
        order.setPembeli(akunPembeli);
        reska_19071002_personList.forEach(x -> {
            if (x.getNama().equalsIgnoreCase(akunPembeli.getNama())) {
                if (x.getSaldo() < hargaProduk) {
                    System.out.println("SALDO TIDAK MENCUKUPI");
                    mulai();
                }

                x.subSaldo(hargaProduk);
                Product p = new Product();
                p.setId(reska_19071002_produk.getId());
                p.setNamaProduk(reska_19071002_produk.getNamaProduk());
                p.setHargaProduk(reska_19071002_produk.getHargaProduk());
                p.setQty(amount);
                x.getProductsYangDibeli().add(p);
            }
        });

        // tambah saldo penjual
        // kurangi count produk di penjual
        reska_19071002_personList.forEach(x -> {
            x.getProductsYangDijual().forEach(y -> {
                if (y.getId().equalsIgnoreCase(reska_19071002_idProduk)) {
                    y.kurangiQty(amount);
                    x.addSaldo(hargaProduk);
                    order.setPenjual(x);
                }
            });
        });

        order.setProduct(reska_19071002_produk);
        reska_19071002_orderList.add(order);

        System.out.println("transaksi berhasil");
        mulai();
    }

    public static Product getProdukById(String idProduk) {
        for (Product reska_19071002_p : reska_19071002_productList) {
            if (reska_19071002_p.getId().equalsIgnoreCase(idProduk)) {
                return reska_19071002_p;
            }
        }
        return null;
    }

    private static Person getAccount(String name) {
        Person p = null;
        for (int i = 0; i < reska_19071002_personList.size(); i++) {
            if (reska_19071002_personList.get(i).getNama().equalsIgnoreCase(name)) {
                p = reska_19071002_personList.get(i);
            }
        }
        return p;
    }

    private static void buatProduk() {
        Scanner reska_19071002_scanner = new Scanner(System.in);
        Scanner reska_19071002_scanner2 = new Scanner(System.in);
        Scanner reska_19071002_scanner3 = new Scanner(System.in);

        System.out.print("Masukkan nama anda   : ");
        String reska_19071002_person = reska_19071002_scanner.nextLine();

        System.out.print("Masukkan nama produk   : ");
        String reska_19071002_nama = reska_19071002_scanner.nextLine();

        System.out.print("Masukkan harga produk  : ");
        Double reska_19071002_harga = reska_19071002_scanner2.nextDouble();

        System.out.print("Masukkan jumlah produk : ");
        int qty = reska_19071002_scanner3.nextInt();

        Product product = new Product(reska_19071002_nama, reska_19071002_harga, qty);
        reska_19071002_productList.add(product);

        reska_19071002_personList.forEach(a -> {
            if (a.getNama().equalsIgnoreCase(reska_19071002_person)) {
                a.addProductDiJual(product);
            }
        });

        System.out.println("PRODUK BERHASIL DITAMBAHKAN");
        mulai();
    }

    private static void buatAkun() {
        Scanner reska_19071002_scanner = new Scanner(System.in);
        System.out.print("Masukkan nama lengkap : ");
        String reska_19071002_nama = reska_19071002_scanner.nextLine();

        System.out.print("Masukkan email       : ");
        String reska_19071002_email = reska_19071002_scanner.nextLine();

        Person reska_19071002_person = new Person(reska_19071002_nama, reska_19071002_email);

        reska_19071002_personList.add(reska_19071002_person);
        System.out.println("BERHASIL");
        mulai();
    }

    public static void header() {
        System.out.println("---------------------------------");
        System.out.println("               SHOP              ");
        System.out.println("---------------------------------");

        System.out.println("1. Buat Akun");
        System.out.println("2. Buat Produk");
        System.out.println("3. Beli Produk");
        System.out.println("4. Detil Akun");
        System.out.println("5. Keluar \n\n");
    }

    public static void footer() {
        System.out.println("\n\n---------------------------------");
        System.out.println("          TERIMA KASIH           ");
        System.out.println("---------------------------------");
    }
}