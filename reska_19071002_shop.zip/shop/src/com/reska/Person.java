package com.reska;

import java.util.ArrayList;

public class Person {
    private String reska_19071002_nama;
    private String reska_19071002_email;
    private Double reska_19071002_saldo;
    private ArrayList<Product> reska_19071002_productsYangDijual;
    private ArrayList<Product> reska_19071002_productsYangDibeli   ;

    public ArrayList<Product> getProductsYangDibeli() {
        return reska_19071002_productsYangDibeli;
    }

    public ArrayList<Product> getProductsYangDijual() {
        return reska_19071002_productsYangDijual;
    }

    public Person(String reska_19071002_nama, String reska_19071002_email) {
        this.reska_19071002_nama = reska_19071002_nama;
        this.reska_19071002_email = reska_19071002_email;
        this.reska_19071002_saldo = 200000d;
        this.reska_19071002_productsYangDibeli = new ArrayList<>();
        this.reska_19071002_productsYangDijual = new ArrayList<>();
    }

    public void addProductDiJual(Product product) {
        this.reska_19071002_productsYangDijual.add(product);
    }

    public void addProductDiBeli(Product product) {
        this.reska_19071002_productsYangDibeli.add(product);
    }

    public Double getSaldo() {
        return reska_19071002_saldo;
    }

    public void addSaldo(double amount) {
        this.reska_19071002_saldo += amount;
    }

    public void subSaldo(double amount) {
        this.reska_19071002_saldo -= amount;
    }

    public void setSaldo(Double reska_19071002_saldo) {
        this.reska_19071002_saldo = reska_19071002_saldo;
    }

    public String getNama() {
        return reska_19071002_nama;
    }

    public void setNama(String reska_19071002_nama) {
        this.reska_19071002_nama = reska_19071002_nama;
    }

    public String getEmail() {
        return reska_19071002_email;
    }

    public void setEmail(String reska_19071002_email) {
        this.reska_19071002_email = reska_19071002_email;
    }
}
