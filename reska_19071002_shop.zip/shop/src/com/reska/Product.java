package com.reska;

import java.util.UUID;

public class Product {
    private String reska_19071002_id;
    private String reska_19071002_namaProduk;
    private int reska_19071002_qty;
    private Double reska_19071002_hargaProduk;

    public Product() {}
    public Product(String reska_19071002_namaProduk, Double reska_19071002_hargaProduk, int reska_19071002_qty) {
        this.reska_19071002_id = UUID.randomUUID().toString();
        this.reska_19071002_namaProduk = reska_19071002_namaProduk;
        this.reska_19071002_hargaProduk = reska_19071002_hargaProduk;
        this.reska_19071002_qty = reska_19071002_qty;
    }

    public void kurangiQty(int amount) {
        this.reska_19071002_qty -= amount;
    }

    public String getId() {
        return reska_19071002_id;
    }

    public void setId(String id) {
        this.reska_19071002_id = id;
    }

    public String getNamaProduk() {
        return reska_19071002_namaProduk;
    }

    public void setNamaProduk(String reska_19071002_namaProduk) {
        this.reska_19071002_namaProduk = reska_19071002_namaProduk;
    }

    public int getQty() {
        return reska_19071002_qty;
    }

    public void setQty(int reska_19071002_qty) {
        this.reska_19071002_qty = reska_19071002_qty;
    }

    public Double getHargaProduk() {
        return reska_19071002_hargaProduk;
    }

    public void setHargaProduk(Double reska_19071002_hargaProduk) {
        this.reska_19071002_hargaProduk = reska_19071002_hargaProduk;
    }
}
