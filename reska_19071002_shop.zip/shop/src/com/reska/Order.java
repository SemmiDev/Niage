package com.reska;

import java.util.UUID;

public class Order {
    private String reska_19071002_ID;
    private Person reska_19071002_penjual;
    private Person reska_19071002_pembeli;
    private Product reska_19071002_product;

    public Order(){}
    public Order(Person reska_19071002_penjual, Person reska_19071002_pembeli, Product reska_19071002_product) {
        this.reska_19071002_ID = UUID.randomUUID().toString();
        this.reska_19071002_penjual = reska_19071002_penjual;
        this.reska_19071002_pembeli = reska_19071002_pembeli;
        this.reska_19071002_product = reska_19071002_product;
    }

    public String getID() {
        return reska_19071002_ID;
    }

    public void setID(String ID) {
        this.reska_19071002_ID = ID;
    }

    public Person getPenjual() {
        return reska_19071002_penjual;
    }

    public void setPenjual(Person reska_19071002_penjual) {
        this.reska_19071002_penjual = reska_19071002_penjual;
    }

    public Person getPembeli() {
        return reska_19071002_pembeli;
    }

    public void setPembeli(Person reska_19071002_pembeli) {
        this.reska_19071002_pembeli = reska_19071002_pembeli;
    }

    public Product getProduct() {
        return reska_19071002_product;
    }

    public void setProduct(Product reska_19071002_product) {
        this.reska_19071002_product = reska_19071002_product;
    }
}
