package com.farhan;

import java.time.LocalDateTime;

public class Transaction {
    private String farhan_19071039_transactionID;
    private LocalDateTime farhan_19071039_time;
    private Account farhan_19071039_fromAccount;
    private Account farhan_19071039_toAccount;
    private Double farhan_19071039_amount;

    public Transaction(String farhan_19071039_transactionID,
                       LocalDateTime farhan_19071039_time,
                       Account farhan_19071039_fromAccount,
                       Account farhan_19071039_toAccount,
                       Double farhan_19071039_amount) {
        this.farhan_19071039_transactionID = farhan_19071039_transactionID;
        this.farhan_19071039_time = farhan_19071039_time;
        this.farhan_19071039_fromAccount = farhan_19071039_fromAccount;
        this.farhan_19071039_toAccount = farhan_19071039_toAccount;
        this.farhan_19071039_amount = farhan_19071039_amount;
    }

    public void setTransactionID(String transactionID) {
        this.farhan_19071039_transactionID = transactionID;
    }

    public void setTime(LocalDateTime time) {
        this.farhan_19071039_time = time;
    }

    public void setFromAccount(Account fromAccount) {
        this.farhan_19071039_fromAccount = fromAccount;
    }

    public void setToAccount(Account toAccount) {
        this.farhan_19071039_toAccount = toAccount;
    }

    public void setAmount(Double amount) {
        this.farhan_19071039_amount = amount;
    }

    public String getTransactionID() {
        return farhan_19071039_transactionID;
    }

    public LocalDateTime getTime() {
        return farhan_19071039_time;
    }

    public Account getFromAccount() {
        return farhan_19071039_fromAccount;
    }

    public Account getToAccount() {
        return farhan_19071039_toAccount;
    }

    public Double getAmount() {
        return farhan_19071039_amount;
    }
}
