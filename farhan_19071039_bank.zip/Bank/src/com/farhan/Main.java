package com.farhan;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    static ArrayList<Account> farhan_19071039_accountList = new ArrayList<>();
    static ArrayList<Transaction> farhan_19071039_transactionList = new ArrayList<>();
    static ArrayList<Wallet> farhan_19071039_walletList = new ArrayList<>();

    public static void main(String[] args) {
        process();
    }

    public static void header() {
        System.out.println("---------------------------------");
        System.out.println("               BANK              ");
        System.out.println("---------------------------------");

        System.out.println("1. Buat Akun");
        System.out.println("2. Isi Saldo");
        System.out.println("3. Melakukan Transaksi");
        System.out.println("4. detail akun");
        System.out.println("5. Keluar \n\n");
    }

    public static void process() {
        Scanner farhan_19071039_scanner = new Scanner(System.in);
        Boolean farhan_19071039_next = true;

        while (farhan_19071039_next) {
            header();
            System.out.print("Masukkan no: ");
            int farhan_19071039_pilihan = farhan_19071039_scanner.nextInt();

            if (farhan_19071039_pilihan == 1) {
                buatAkun();
            }else if (farhan_19071039_pilihan == 2) {
                isiSaldo();
            }else if (farhan_19071039_pilihan == 3) {
                transaksi();
            }else if (farhan_19071039_pilihan == 4) {
                detailAkun();
            }else {
                System.exit(0);
            }

            int isNext = farhan_19071039_scanner.nextInt();
            if (isNext == 1) {
                farhan_19071039_next = true;
            }else {
                farhan_19071039_next = false;
            }
        }
    }

    private static void detailAkun() {
        Scanner farhan_19071039_scanner = new Scanner(System.in);
        System.out.print("Masukkan email anda : ");
        String farhan_19071039_email = farhan_19071039_scanner.nextLine();

        Account acc = searchAkun(farhan_19071039_email);
        System.out.println("--------------DETAILS--------------");
        System.out.println("ID    :" + acc.getAccountID());
        System.out.println("NAME  :" + acc.getFullName());
        System.out.println("EMAIL :" + acc.getEmail());
        System.out.println("PHONE :" + acc.getPhoneNumber());
        System.out.println("SALDO :" + acc.getWallet().getBalance());
        System.out.println("-----------------------------------");
        process();
    }

    private static void transaksi() {
        double farhan_19071039_biayaTransaksi = 100d;
        Scanner farhan_19071039_scanner = new Scanner(System.in);

        String farhan_19071039_transactionID = UUID.randomUUID().toString();
        LocalDateTime farhan_19071039_time = LocalDateTime.now();

        System.out.print("Masukkan email kamu  : ");
        String farhan_19071039_emailKamu = farhan_19071039_scanner.nextLine();
        Account farhan_19071039_source = searchAkun(farhan_19071039_emailKamu);

        System.out.print("Masukkan email target  : ");
        String farhan_19071039_emailTarget = farhan_19071039_scanner.nextLine();
        Account farhan_19071039_target = searchAkun(farhan_19071039_emailTarget);

        System.out.print("Masukkan amount  : ");
        Double farhan_19071039_amount = farhan_19071039_scanner.nextDouble();

        if (farhan_19071039_source == null && farhan_19071039_target == null) {
            System.out.println("TRANSAKSI GAGAL AKUN TIDAK DITEMUKAN");
        }else {
            // tambah saldo
            tambahKeTarget(farhan_19071039_target, farhan_19071039_amount);
            // kurang saldo
            kurangisiPengirim(farhan_19071039_source, farhan_19071039_amount, farhan_19071039_biayaTransaksi);
        }

        Transaction transaction = new Transaction(farhan_19071039_transactionID, farhan_19071039_time, farhan_19071039_source, farhan_19071039_target, farhan_19071039_amount);
        farhan_19071039_transactionList.add(transaction);
        process();
    }

    public static void tambahKeTarget(Account acc,  double amount) {
        for (int i = 0; i < farhan_19071039_accountList.size(); i++) {
            if (farhan_19071039_accountList.get(i).getEmail().equalsIgnoreCase(acc.getEmail())) {
                farhan_19071039_accountList.get(i).getWallet().addBalance(amount);
            }
        }
    }

    public static void kurangisiPengirim(Account acc,  double amount, double biayaTransaksi) {
        for (int i = 0; i < farhan_19071039_accountList.size(); i++) {
            if (farhan_19071039_accountList.get(i).getEmail().equalsIgnoreCase(acc.getEmail())) {
                farhan_19071039_accountList.get(i).getWallet().subBalance(amount);

                double farhan_19071039_biaya = biayaTransaksi;
                if (amount > 100000) {
                    farhan_19071039_biaya = (amount / 100000) * biayaTransaksi;
                }

                farhan_19071039_accountList.get(i).getWallet().subBalance(farhan_19071039_biaya);
            }
        }
    }

    public static Account searchAkun(String email) {
        Account account = null;
        for (int i = 0; i < farhan_19071039_accountList.size(); i++) {
            if (farhan_19071039_accountList.get(i).getEmail().equalsIgnoreCase(email)) {
                account = farhan_19071039_accountList.get(i);
            }
        }
        return account;
    }

    private static void isiSaldo() {
        Scanner farhan_19071039_scanner = new Scanner(System.in);
        Scanner farhan_19071039_scanner2 = new Scanner(System.in);

        System.out.print("Masukkan email  : ");
        String farhan_19071039_email = farhan_19071039_scanner.nextLine();

        System.out.print("Masukkan jumlah : Rp.");
        double farhan_19071039_amount = farhan_19071039_scanner2.nextDouble();

        Account farhan_19071039_account = null;
        for (int i = 0; i < farhan_19071039_accountList.size(); i++) {
            if (farhan_19071039_accountList.get(i).getEmail().equalsIgnoreCase(farhan_19071039_email)) {
                farhan_19071039_account = farhan_19071039_accountList.get(i);
            }
        }

        if (farhan_19071039_account == null) {
            System.out.println("AKUN BERLUM TERDAFTAR");
            process();
        }

        farhan_19071039_accountList.forEach(x -> {
            if (x.getEmail().equalsIgnoreCase(farhan_19071039_email)) {
                x.getWallet().addBalance(farhan_19071039_amount);
            }
        });

        System.out.println("BERHASIL MENAMBAH SALDO");
        process();
    }

    private static void buatAkun() {
        Scanner farhan_19071039_scanner = new Scanner(System.in);
        System.out.print("Masukkan nama lengkap : ");
        String farhan_19071039_nama = farhan_19071039_scanner.nextLine();

        System.out.print("Masukkan email       : ");
        String farhan_19071039_email = farhan_19071039_scanner.nextLine();

        System.out.print("Masukkan no telp     : ");
        String farhan_19071039_telp = farhan_19071039_scanner.nextLine();

        Wallet wallet = new Wallet(UUID.randomUUID().toString(), 0d);
        Account account = new Account(UUID.randomUUID().toString(), farhan_19071039_nama, farhan_19071039_email ,farhan_19071039_telp, wallet);

        farhan_19071039_walletList.add(wallet);
        farhan_19071039_accountList.add(account);
        System.out.println("AKUN BERHASIL DIBUAT");
        process();
    }
}