package com.farhan;

public class Wallet {
    private String farhan_19071039_walletID;
    private Double farhan_19071039_balance;

    public Wallet(String farhan_19071039_walletID, Double farhan_19071039_balance) {
        this.farhan_19071039_walletID = farhan_19071039_walletID;
        this.farhan_19071039_balance = farhan_19071039_balance;
    }

    public void addBalance(double balance) {
        this.farhan_19071039_balance += balance;
    }

    public void subBalance(double balance) {
        this.farhan_19071039_balance -= balance;
    }

    public String getWalletID() {
        return farhan_19071039_walletID;
    }

    public void setWalletID(String walletID) {
        this.farhan_19071039_walletID = walletID;
    }

    public Double getBalance() {
        return farhan_19071039_balance;
    }

    public void setBalance(Double balance) {
        this.farhan_19071039_balance = balance;
    }
}
