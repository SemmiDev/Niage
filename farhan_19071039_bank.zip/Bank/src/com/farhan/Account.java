package com.farhan;

public class Account {
    private String farhan_19071039_accountID;
    private String farhan_19071039_fullName;
    private String farhan_19071039_email;
    private String farhan_19071039_phoneNumber;
    private Wallet farhan_19071039_wallet;

    public Account(String farhan_19071039_accountID,
                   String farhan_19071039_fullName,
                   String farhan_19071039_email,
                   String farhan_19071039_phoneNumber,
                   Wallet farhan_19071039_wallet) {
        this.farhan_19071039_accountID = farhan_19071039_accountID;
        this.farhan_19071039_fullName = farhan_19071039_fullName;
        this.farhan_19071039_email = farhan_19071039_email;
        this.farhan_19071039_phoneNumber = farhan_19071039_phoneNumber;
        this.farhan_19071039_wallet = farhan_19071039_wallet;
    }

    public String getAccountID() {
        return farhan_19071039_accountID;
    }

    public void setAccountID(String farhan_19071039_accountID) {
        this.farhan_19071039_accountID = farhan_19071039_accountID;
    }

    public String getFullName() {
        return farhan_19071039_fullName;
    }

    public void setFullName(String fullName) {
        this.farhan_19071039_fullName = fullName;
    }

    public String getEmail() {
        return farhan_19071039_email;
    }

    public void setEmail(String email) {
        this.farhan_19071039_email = email;
    }

    public String getPhoneNumber() {
        return farhan_19071039_phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.farhan_19071039_phoneNumber = phoneNumber;
    }

    public Wallet getWallet() {
        return farhan_19071039_wallet;
    }

    public void setWallet(Wallet wallet) {
        this.farhan_19071039_wallet = wallet;
    }
}